* * * * * * * * * *

TAMELESS WORLD, Resource Pack

* * * * * * * * * *

This 'Resource Pack' is made and produced by ArtsByKev.
https://www.youtube.com/artsbykev

- - - - -

License:

The contents of this pack may under no cirkumstances be used for
commercial use on, in, and around your own projects without a
formally written and signed agreement provided by ArtsByKev, with
a proof copy sent from business.artsbykev@gmail.com
Infringement is not tolerated, and should such an email not be correctly formated or presentable at the
finding of you using contents from this pack, we kindly ask you to
terminate those files and send for an actual agreement.

- - - - -

(c) Copyright: ArtsByKev (author) with full standalone rights.